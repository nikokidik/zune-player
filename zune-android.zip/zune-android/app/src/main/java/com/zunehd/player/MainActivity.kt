package com.zunehd.player

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.util.Base64
import android.util.Size
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var mp: MediaPlayer? = null
    private val prefs by lazy { getSharedPreferences("zune", Context.MODE_PRIVATE) }

    companion object {
        const val REQ_PERM = 1
        const val REQ_FOLDER = 2
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.setBackgroundColor(Color.BLACK)
        web.addJavascriptInterface(Bridge(), "Native")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    override fun onBackPressed() {
        web.evaluateJavascript("navBack()") { r ->
            if (r != "true") finish()
        }
    }

    override fun onDestroy() {
        try { mp?.release() } catch (e: Exception) { }
        mp = null
        super.onDestroy()
    }

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    private fun permName(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasPerm(): Boolean =
        checkSelfPermission(permName()) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERM) {
            if (hasPerm()) scan() else js("onNoPerm()")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FOLDER && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val docId = DocumentsContract.getTreeDocumentId(uri)
                val rel = docId.substringAfter(":", "")
                val name = rel.substringAfterLast("/").ifEmpty { "root" }
                prefs.edit()
                    .putString("rel", rel)
                    .putString("folderName", name)
                    .putString("mode", "folder")
                    .apply()
                js("onSettings(" + JSONObject.quote(settingsJson()) + ")")
                scan()
            } catch (e: Exception) {
                js("onErr()")
            }
        }
    }

    private fun settingsJson(): String =
        JSONObject()
            .put("mode", prefs.getString("mode", "all"))
            .put("folder", prefs.getString("folderName", ""))
            .toString()

    private fun scan() {
        Thread {
            try {
                val sel = StringBuilder(
                    "duration >= 30000 AND is_ringtone = 0 AND is_notification = 0 AND is_alarm = 0"
                )
                val args = ArrayList<String>()
                if (prefs.getString("mode", "all") == "folder") {
                    val rel = (prefs.getString("rel", "") ?: "").trim('/')
                    if (rel.isNotEmpty()) {
                        sel.append(" AND _data LIKE ?")
                        args.add("%/$rel/%")
                    }
                }
                val cols = arrayOf(
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM,
                    MediaStore.Audio.Media.DURATION
                )
                val list = ArrayList<JSONObject>()
                contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    cols, sel.toString(), args.toTypedArray(), null
                )?.use { c ->
                    while (c.moveToNext()) {
                        var artist = c.getString(2) ?: ""
                        if (artist.isEmpty() || artist == "<unknown>") artist = "Unknown artist"
                        var album = c.getString(3) ?: ""
                        if (album.isEmpty() || album == "<unknown>") album = "Unknown album"
                        val o = JSONObject()
                        o.put("id", c.getLong(0).toString())
                        o.put("title", c.getString(1) ?: "Unknown")
                        o.put("artist", artist)
                        o.put("album", album)
                        o.put("dur", c.getLong(4))
                        list.add(o)
                    }
                }
                list.sortBy { it.getString("title").lowercase() }
                val arr = JSONArray()
                for (o in list) arr.put(o)
                js("onTracks(" + JSONObject.quote(arr.toString()) + ")")
            } catch (e: SecurityException) {
                js("onNoPerm()")
            } catch (e: Exception) {
                js("onErr()")
            }
        }.start()
    }

    inner class Bridge {

        @JavascriptInterface
        fun init() {
            if (hasPerm()) {
                scan()
            } else {
                runOnUiThread { requestPermissions(arrayOf(permName()), REQ_PERM) }
            }
        }

        @JavascriptInterface
        fun settings(): String = settingsJson()

        @JavascriptInterface
        fun setMode(m: String) {
            prefs.edit().putString("mode", m).apply()
            js("onSettings(" + JSONObject.quote(settingsJson()) + ")")
            init()
        }

        @JavascriptInterface
        fun pickFolder() {
            runOnUiThread {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_FOLDER)
            }
        }

        @JavascriptInterface
        fun play(id: String) {
            runOnUiThread {
                try {
                    mp?.release()
                    val uri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toLong()
                    )
                    val p = MediaPlayer()
                    p.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .build()
                    )
                    p.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
                    p.setDataSource(applicationContext, uri)
                    p.setOnPreparedListener { it.start() }
                    p.setOnCompletionListener { js("onEnded()") }
                    p.setOnErrorListener { _, _, _ -> js("onErr()"); true }
                    p.prepareAsync()
                    mp = p
                } catch (e: Exception) {
                    js("onErr()")
                }
            }
        }

        @JavascriptInterface
        fun toggle() {
            try {
                mp?.let { if (it.isPlaying) it.pause() else it.start() }
            } catch (e: Exception) { }
        }

        @JavascriptInterface
        fun seek(ms: Int) {
            try { mp?.seekTo(ms) } catch (e: Exception) { }
        }

        @JavascriptInterface
        fun state(): String {
            val p = mp ?: return "0,0,0"
            return try {
                "${p.currentPosition},${p.duration},${if (p.isPlaying) 1 else 0}"
            } catch (e: Exception) {
                "0,0,0"
            }
        }

        @JavascriptInterface
        fun art(id: String): String {
            if (Build.VERSION.SDK_INT < 29) return ""
            return try {
                val uri = ContentUris.withAppendedId(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toLong()
                )
                val bmp = contentResolver.loadThumbnail(uri, Size(480, 480), null)
                val bo = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 85, bo)
                "data:image/jpeg;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
            } catch (e: Exception) {
                ""
            }
        }
    }
}
