package com.zunehd.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder

class PlayerService : Service() {

    companion object {
        var title = ""
        var artist = ""
        var playing = false
        var inst: PlayerService? = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        inst = this
    }

    override fun onDestroy() {
        inst = null
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val a = intent?.action
        if (a == "PREV" || a == "TOGGLE" || a == "NEXT") {
            MainActivity.instance?.cmd(a)
        }
        refresh()
        return START_NOT_STICKY
    }

    fun refresh() {
        val n = build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, n)
        }
    }

    private fun act(a: String, ic: Int, label: String): Notification.Action {
        val pi = PendingIntent.getService(
            this, a.hashCode(),
            Intent(this, PlayerService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Action.Builder(Icon.createWithResource(this, ic), label, pi).build()
    }

    private fun build(): Notification {
        val ch = "zune"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(ch, "Playback", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, ch)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(artist)
            .setContentIntent(open)
            .addAction(act("PREV", android.R.drawable.ic_media_previous, "prev"))
            .addAction(
                act(
                    "TOGGLE",
                    if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                    "play"
                )
            )
            .addAction(act("NEXT", android.R.drawable.ic_media_next, "next"))
            .setStyle(Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2))
            .setOngoing(true)
            .build()
    }
}
